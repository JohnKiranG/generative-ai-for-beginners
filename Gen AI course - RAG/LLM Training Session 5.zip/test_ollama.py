import requests
import json


url = "http://localhost:11434/api/generate"

payload = {
    "model": "llama3",
    "prompt": "Explain Agentic AI in 3 lines.",
    "stream": False
}

response = requests.post(url, json=payload)

if response.status_code == 200:
    data = response.json()
    print("\nModel Response:\n")
    print(data["response"])
else:
    print("Error:", response.status_code, response.text)