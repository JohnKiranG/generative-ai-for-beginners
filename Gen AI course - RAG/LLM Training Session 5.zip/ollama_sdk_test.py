from ollama import chat

response = chat(
    model='llama3',
    messages=[
        {"role": "user", "content": "Explain why local LLMs improve data privacy"}
    ]
)

print("\nModel Response:\n")
print(response['message']['content'])